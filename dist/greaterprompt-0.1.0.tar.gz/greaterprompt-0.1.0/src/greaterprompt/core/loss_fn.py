# TODO: currently only implemented cross entropy, move cross entropy and perplexity to this file in needed


class LossFn:
    def __init__(self):
        pass
    