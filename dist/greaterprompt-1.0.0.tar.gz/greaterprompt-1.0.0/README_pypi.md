🤗 check our [Github](https://github.com/WenliangZhoushan/GreaterPrompt) page for more details
