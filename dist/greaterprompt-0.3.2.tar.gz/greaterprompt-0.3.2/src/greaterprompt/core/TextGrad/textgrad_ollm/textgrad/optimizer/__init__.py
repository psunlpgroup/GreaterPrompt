from .optimizer import TextualGradientDescent, Optimizer, TextualGradientDescentwithMomentum

TGD = TextualGradientDescent
