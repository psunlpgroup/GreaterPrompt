# TODO: now extractor is given by user, is it possible to extract the answer automatically?

class BaseParser:
    pass
