# TODO: in the future try to support different tasks and extractors in one dataset


class InputCollector:
    def __init__(self, dataset_path: str):
        pass
