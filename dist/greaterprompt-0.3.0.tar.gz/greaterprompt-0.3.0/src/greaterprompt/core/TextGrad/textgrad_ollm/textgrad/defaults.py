SYSTEM_PROMPT_DEFAULT_ROLE = (
    "system prompt to the language model that specifies the behavior and strategies, which will be reused across queries"
)
VARIABLE_INPUT_DEFAULT_ROLE = "query to the language model"
VARIABLE_OUTPUT_DEFAULT_ROLE = "response from the language model"
