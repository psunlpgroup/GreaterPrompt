# Running Reflexion

We run [Reflexion](https://github.com/vinid/reflexion) with some minor edits (the link points to our fork not the original).
Original code can be found [here](https://github.com/noahshinn/reflexion).

This is the script we ran: [link](https://github.com/vinid/reflexion/blob/main/programming_runs/run_reflexion_py_leet.sh).
