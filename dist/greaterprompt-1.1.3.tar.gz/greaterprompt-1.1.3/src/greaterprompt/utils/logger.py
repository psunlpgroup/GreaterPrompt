# TODO: since we are going to build this into a python package, do we really need this logger?


class Logger:
    def __init__(self):
        pass
    