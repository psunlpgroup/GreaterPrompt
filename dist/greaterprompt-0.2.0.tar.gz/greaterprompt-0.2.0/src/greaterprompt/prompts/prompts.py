# TODO: maybe could define a class to store each prompt for better organization


class Prompt:
    def __init__(self):
        pass
